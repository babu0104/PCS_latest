import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { User } from '../../_models/index';
import { AuthState } from '../../_models/authstate';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { UserLoginService } from '../../services/userLoginService';
import * as _ from 'underscore';
import { Util } from '../../util'

declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [Util],
})

export class HeaderComponent implements OnInit {
  model: User = new User();
  authState: AuthState;
  userNameIsValid: boolean;
  userData: any;
  isNameEntered: boolean;
  isUserPresent: any;
  showSignIn: boolean;
  public token: string;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: Auth_UserService,
    private userLoginService: UserLoginService,
    private utilObject: Util
  ) {
   
  }


  ngOnInit() {
    //oninit check if jwt is present for current user.
    //if it present, make it loggedin true
  }



  onSubmit(event) {
    let _self = this;
    let result, obj;
    let userNameVal = this.model.userName;
    let enteredUserName = (userNameVal === undefined || userNameVal.length <= 0) ? false : true;
    if (enteredUserName) {
      localStorage.setItem('userName', userNameVal);
      this.router.navigate(['/login']);
    } else {
      this.model.isUserNamePresent = false;
    }
    this.model.userName='';
  }

  navToLanding(event){
    debugger;
    if(this.isLoggedIn())
      return false;
    else{
      this.router.navigate(['']);
    }
  }
  signOut(): void {
    // clear token remove user from local storage to log user out
    this.token = null;
     this.utilObject.clearLocalStorage();
    AuthState.isLoggedIn = false;
    this.router.navigate(['']);
  }

  public isLoggedIn(): boolean {
    let currentUser = localStorage.getItem('currentUser');
    if (_.isNull(currentUser) || _.isUndefined(currentUser))
      this.isUserPresent = false;
    else
      this.isUserPresent = true;

    return this.isUserPresent;
  }

  showSignInForm(event) {
    document.getElementById('sigin-link').classList.toggle('sign-form-show');
  }
  onClickedOutside(e: Event) {
    document.getElementById('sigin-link').classList.remove('sign-form-show');
  }
}
