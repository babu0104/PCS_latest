import { Injectable } from '@angular/core';

// @Injectable();
export class LoginService{
    isHovered: boolean = false;
    //Has to integrate with actual service
    getStatus(){
        this.isHovered = true;
        //servcie goes here
        return this.isHovered;
    }

}
