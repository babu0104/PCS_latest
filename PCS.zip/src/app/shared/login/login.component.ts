import { Component, OnInit,ElementRef,ViewChild, Renderer } from '@angular/core';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common'
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { UserLoginService } from '../../services/userLoginService';
import { NgForm } from '@angular/forms';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { User } from '../../_models/user';
import { AuthState } from '../../_models/authstate';
import * as _ from 'underscore';
import { Role } from '../../_models/Role';
import { Util } from '../../util';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [Util],
})
export class LoginComponent implements OnInit {
  @ViewChild('myInput') input: ElementRef;
  model = new User();
  authState: AuthState;
  loading = false;
  error = '';
  roleModel = new Role();
  userName: any;
  isUserPresent: any;
  loginCancelled: boolean = false;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: Auth_UserService,
    private userLoginService: UserLoginService,
    private utilObject: Util,
    private location: PlatformLocation,
    private renderer: Renderer
  ) {
    this.utilObject.hideSignInLink();
    location.onPopState(() => {
          this.model.userName = '';
    });
    this.PreventBack();
   }

  ngOnInit() {
   let _self = this;
    this.userName = localStorage.getItem('userName');
    if(this.userName)
      { 
      this.renderer.invokeElementMethod(this.input.nativeElement, 'focus');
    }
    else{
      this.router.navigate(['']);
    }
  }

  login() {
    let _self = this;
    this.loading = true;
    //service to get username , pwd
    this.userService.validateUser(this.userName, this.model.password)
      .subscribe(result => {
        if (result === true) {
          setTimeout(function () { //temp time delay for spinner
            _self.loading = false;
            AuthState.isLoggedIn = true;
            _self.router.navigate(['/pcs-home/home']);
          }, 1000);
        } else {
          this.error = 'Please fill the password';
          this.loading = false;
        }
      });
  }
 PreventBack(){
    // history.forward();
  }
  passwordKeyDown(event) {
    if ((!_.isUndefined(event)) && event.keyCode == 13) {
      this.login();
    }
  }

  onCancel(event) {
    this.model.userName = '';
    this.utilObject.clearLocalStorage();
    this.router.navigate(['']);
  }
}
