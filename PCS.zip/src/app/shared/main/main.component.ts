import { Component, OnInit } from '@angular/core';
import { Util } from '../../util';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  providers:[Util],
})
export class MainComponent implements OnInit {
  constructor(private util : Util) { 
  }

  ngOnInit() {
  }
  ngAfterViewInit(){
    //stuff that doesn't do view changes
    setTimeout(_=> this.util.showSignInLink()); 
  } 

}
