import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import { Util } from '../../util';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss'],
  providers: [
      { provide: Window, useValue: window }, Util
  ],
})
export class FaqComponent implements OnInit {

  constructor(@Inject(Window) private window: Window, private util : Util) {
    this.util.showSignInLink();
   }

  ngOnInit() {
  }

  scroll(el) {
    el.scrollIntoView();
  }

  toTop(){
    console.log('top');
      this.window.document.body.scrollIntoView();
  }
}
