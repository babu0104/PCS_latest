export interface User {
	firstName;
	lastName;
	userId;
	roleDto;
	roleDesc;
	service,
	usercreationDate,
	lastModifiedDate,
	lastLoginDate,
	status;
	email;
	phone;
	secPhase;
	ipAddress;
	ics;
	pcs;
}	