export class User {
    userName: string;
    password: string;
    firstName: string;
    lastName : string;
    secImage : string;
    secPhrase : string;
    userId : string;
    role : string;     
    isUserNamePresent : boolean;
    isActive : boolean;
}