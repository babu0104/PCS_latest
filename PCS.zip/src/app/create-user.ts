export class CreateUser {
    public userId: string;
    public firstName: string;
    public lastName: string;
    public phone: string;
    public email: string;
    public ics: string;
    public pcs: string;
    public secPhase: string;
    public secImg: string;
    public ipAddress: string;
    public roleDto: {
        roleId: string,
        roleDesc: string,
        hierarchyValue: string;
    };
    public status: string;
    public lastModifiedDate: string;
    public lastLoginDate: string;
    public usercreationDate: string;


    public bidCode: number;
    public bidDesc: string;
    public subTypeCode: number;
    public subTypeSys: string;
    public subTypeDesc: string;
    constructor() { }
}
