export class fileUpload {
        bid : number;
        service : string;
        bin : number;
        filetype : string;
        layout : string;
        submissionType : string;
        template : string;
        description : string;
        file : File;

        public clear(){
            console.log(this);
            this.filetype = '-1';
            this.layout = ''; 
        }
}

// https://github.com/primefaces/primeng/blob/master/src/app/showcase/components/selectbutton/selectbuttondemo.tss