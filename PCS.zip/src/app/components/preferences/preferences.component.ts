import { Component, OnInit,ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { Util } from '../../util';
declare var $: any


@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.scss']
})
export class PreferencesComponent implements OnInit {
 utilObject: Util;
  constructor(private router: Router,private elRef: ElementRef) {
    this.utilObject = new Util();
   }
    onCancel(event){
		this.router.navigate(['/pcs-home/home']);
	}
  ngOnInit() {
  }
  onkeyup(event)
  {
    this.utilObject.onFocus(event.target.value,this.elRef.nativeElement,event.keyCode);
  }

}
