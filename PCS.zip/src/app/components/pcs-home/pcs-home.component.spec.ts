import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PcsHomeComponent } from './pcs-home.component';

describe('PcsHomeComponent', () => {
  let component: PcsHomeComponent;
  let fixture: ComponentFixture<PcsHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PcsHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PcsHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
