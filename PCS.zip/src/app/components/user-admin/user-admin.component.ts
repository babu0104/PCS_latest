import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../../interfaces/user';
import { UserService } from '../../services/userservices';
import { PcsHomeComponent } from '../../components/pcs-home/pcs-home.component';
import { Router } from '@angular/router';
import { LazyLoadEvent, DataTable } from 'primeng/primeng';

@Component({
  selector: 'app-user-admin',
  templateUrl: './user-admin.component.html',
  styleUrls: ['./user-admin.component.scss']
})

export class UserAdminComponent implements OnInit {
  @ViewChild('dt') userTable: DataTable;

  loading: boolean;
  users: User[];
  datasource: User[];
  searchResult: User[];
  cols: any[];
  showNewUser: boolean = false;
  showUserAdmin: boolean = true;
  showEditUser: boolean = false;
  selectedStatus: boolean;
  userDetail: any;
  searchValue: string;
  loggedInUserRoleId: string;
  userRoleId: string;
  totalRecords: number;

  constructor(private userService: UserService, private router: Router,private pcshomecomponent:PcsHomeComponent) { }

  editUser(userId) {
    this.showEditUser = !this.showEditUser;
    this.showUserAdmin = !this.showUserAdmin;

    this.userDetail = this.users.filter(function (node) {
      return node.userId == userId;
    });
  }

  createNewUser() {
    this.showNewUser = !this.showNewUser;
    this.showUserAdmin = !this.showUserAdmin;
  }

  ngOnInit() {
    this.loading = true;
    setTimeout(() => {
    this.loggedInUserRoleId = this.userService.getLoggedInUserRoleId();
    this.loggedInUserRoleId="1";
   
    //this.loggedInUserRoleId=this.pcshomecomponent.setRole();

      let page = 0, size, searchValue;
      this.userService.getUsers(this.loggedInUserRoleId, page, size, searchValue).subscribe(res => {
        this.datasource = res.baseDtoList;
        this.totalRecords = res.countOfRecords;
        this.users = this.datasource;
      });
      this.loading = false;

      this.cols = [
        { field: 'name', header: 'Name' },
        { field: 'userId', header: 'userId' },
        { field: 'userRole', header: 'role', nested: true },
        { field: 'ics', header: 'service' },
        { field: 'usercreationDate', header: 'created' },
        { field: 'lastModifiedDate', header: 'modified' },
        { field: 'lastLoginDate', header: 'last_login' },
        { field: 'status', header: 'status' }
      ];
    }, 100);
  }

  loadUsersLazy(event: LazyLoadEvent) {
    if (this.datasource != undefined) {
      let page = (event.first / event.rows);
      this.userService.getUsers(this.loggedInUserRoleId, page, event.rows, this.searchValue).subscribe(res => {
        let self = this;
        self.searchResult = res.baseDtoList;
        self.totalRecords = res.countOfRecords;
        self.datasource = self.searchResult;
        self.users = self.datasource;
        self.userTable.updateDataToRender(self.users);
      });
    }
  }

  handleInactiveUser(event) {
    let checked = event.currentTarget.checked;
    this.selectedStatus = checked ? true : false;

    // placeholder for an api call to filter user admin table based on this.selectedStatus value
  }

  checkInputValue(event) {
    if (event.keyCode === 13) { // if user press enter
      this.userTableGlobalFilter(this.searchValue, this.userTable);
    } else {
      return;
    }
  }

  userTableGlobalFilter(searchValue, userTable) {
    this.searchValue = searchValue;
    userTable.reset();
  }
}


