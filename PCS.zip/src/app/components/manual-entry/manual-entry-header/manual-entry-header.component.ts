import { Component, OnInit } from '@angular/core';
import { manualEntryHeader } from './manual-entry-header.modal';

@Component({
  selector: 'app-manual-entry-header',
  templateUrl: './manual-entry-header.component.html',
  styleUrls: ['./manual-entry-header.component.scss']
})
export class ManualEntryHeaderComponent implements OnInit {
  
  manualEntryHeaderObj : manualEntryHeader;

  constructor() {
    this.manualEntryHeaderObj = new manualEntryHeader();
   }

  ngOnInit() {
    this.manualEntryHeaderObj.locatorNumber = 123456;
    this.manualEntryHeaderObj.bid = 88888883;
    this.manualEntryHeaderObj.service = 'pcs'
    this.manualEntryHeaderObj.bin = 444448;
    this.manualEntryHeaderObj.mso = 'B';
    console.log(this.manualEntryHeaderObj);
  }

}
