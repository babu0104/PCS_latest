import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryPrepaidInquiryComponent } from './manual-entry-prepaid-inquiry.component';

describe('ManualEntryPrepaidInquiryComponent', () => {
  let component: ManualEntryPrepaidInquiryComponent;
  let fixture: ComponentFixture<ManualEntryPrepaidInquiryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryPrepaidInquiryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryPrepaidInquiryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
