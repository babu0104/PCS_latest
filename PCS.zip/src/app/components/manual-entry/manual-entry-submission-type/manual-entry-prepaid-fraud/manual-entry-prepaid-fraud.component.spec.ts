import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryPrepaidFraudComponent } from './manual-entry-prepaid-fraud.component';

describe('ManualEntryPrepaidFraudComponent', () => {
  let component: ManualEntryPrepaidFraudComponent;
  let fixture: ComponentFixture<ManualEntryPrepaidFraudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryPrepaidFraudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryPrepaidFraudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
