import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryProvisionalCreditRequestComponent } from './manual-entry-provisional-credit-request.component';

describe('ManualEntryProvisionalCreditRequestComponent', () => {
  let component: ManualEntryProvisionalCreditRequestComponent;
  let fixture: ComponentFixture<ManualEntryProvisionalCreditRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryProvisionalCreditRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryProvisionalCreditRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
