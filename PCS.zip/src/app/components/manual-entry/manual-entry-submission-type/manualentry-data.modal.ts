/** 
 * This modal(class) contains the methods and properties for manual entry enter data
 * will be used across all the data in the specific submission type
 * this model extends by individual submission type modals to have data collectively
 * for more info please refere file upload module
 **/

import { manualEntryHeader } from '../manual-entry-header/manual-entry-header.modal'

export class manualEntryFormData extends manualEntryHeader{
    fraudType : string;
    fraudAmount : number;
    prepaiAccount : string;
    f_name : string;
    m_name ? : string;
    l_name : string;
    ssn : number;
    dob : Date;
    address_1 : string;
    address_2 : string;
    city : string;
    state : string;
    zipcode : string;
    current_phone : number;
    secondary_phone : number;
    email : string;
    ip : number;
    device_id : string;
    device_id_provider : string;
    comments ? : string;
    // locatorNumber ?: number;  //can not be a mandatory
    clearAll (){        
        this.fraudType = '' || undefined;
        this.fraudAmount = '' || undefined;              
        this.prepaiAccount = '' || undefined;
        this.f_name = '' || undefined;
        this.m_name = '' || undefined;
        this.l_name = '' || undefined;
        this.ssn = '' || undefined;
        this.dob = '' || undefined;
        this.address_1 = '' || undefined;
        this.address_2 = '' || undefined;
        this.city = '' || undefined;
        this.state = '' || undefined;
        this.zipcode = '' || undefined;
        this.current_phone = '' || undefined;
        this.secondary_phone = '' || undefined;
        this.email = '' || undefined;
        this.ip = '' || undefined;
        this.device_id = '' || undefined;
        this.device_id_provider = '' || undefined;
        this.comments = '' || undefined;

    }
}