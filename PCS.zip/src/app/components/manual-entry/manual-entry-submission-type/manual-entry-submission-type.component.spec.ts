import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntrySubmissionTypeComponent } from './manual-entry-submission-type.component';

describe('ManualEntrySubmissionTypeComponent', () => {
  let component: ManualEntrySubmissionTypeComponent;
  let fixture: ComponentFixture<ManualEntrySubmissionTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntrySubmissionTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntrySubmissionTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
