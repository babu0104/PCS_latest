import { Component, OnInit, TemplateRef } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { Headers, Response, RequestOptions, URLSearchParams, Http } from '@angular/http';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SecurityImage } from '../../interfaces/user-admin-images';
import { UserAdmin } from '../../interfaces/user-admin';
import { UserService } from '../../services/userservices';
import { CreateUser } from '../../create-user';
import { userRoleService } from '../../services/user-roles-services';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as _ from 'underscore';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';

import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  providers: [userRoleService, MessageService]
})

export class NewUserComponent implements OnInit {
  msgs: Message[] = [];
  commonError: boolean;
  images: any[];
  public modalRef: BsModalRef;
  securityImageUrl: any;
  selectedImageUrl: any;
  showUserAdmin: boolean = false;
  showNewUser: boolean = true;
  loading: boolean;
  users: any[];
  cols: any[];
  roles: any[];
  bids: any[];
  submissiontypes: any[];
  selectedBids: any[];
  selectedBins: any[];
  selectedSubmitTypes: any[];
  createuser = new CreateUser();
  userRoles: any;
  selectedRole: any;
  loggedInUserRoleId: string;

  date: string;
  constructor(private router: Router,
    private modalService: BsModalService,
    private userService: UserService,
    private http: Http,
    private userRoleService: userRoleService,
    private messageService: MessageService) {
    // this.images = [
    //   { imgname: '1' }, { imgname: '3' }, { imgname: '4' }, { imgname: '5' }, { imgname: '6' },
    //   { imgname: '7' }, { imgname: '8' }, { imgname: '9' }, { imgname: '10' }, { imgname: '11' },
    //   { imgname: '12' }, { imgname: '13' }, { imgname: '14' }, { imgname: '15' },
    //   { imgname: '16' }, { imgname: '17' }, { imgname: '18' }, { imgname: '19' }, { imgname: '20' },
    //   { imgname: '21' }, { imgname: '22' }, { imgname: '23' }, { imgname: '24' }, { imgname: '25' },
    //   { imgname: '26' }, { imgname: '27' }, { imgname: '28' }, { imgname: '29' }
    // ];


    this.date = 'currentDate'

    let dp = new DatePipe('de-DE' /* locale .. */);
    this.date = dp.transform(new Date(), 'dd-MM-yyyy');
    console.log(this.date);

  }

  ngOnInit() {
    this.commonError = false;
    this.loading = true;
    this.createuser.ics = "0";
    this.createuser.pcs = "0";
    setTimeout(() => {
      this.userRoleService.getuserrbid().subscribe(res => this.bids = res);
      this.userRoleService.getuserrbin().subscribe(res => this.bids = res);
      this.userRoleService.getsubmissiontypes().subscribe(res => this.submissiontypes = res);
      this.loading = false;
    }, 1000);

    this.cols = [
      { field: 'bidDesc', header: 'BIDs' },
      { field: 'biNDesc', header: 'BINs' },
      { field: 'subTypeDesc', header: 'Submit Type' }
    ];
    this.getUserRoleById();

  }


  getUserRoleById() {
    this.loggedInUserRoleId = this.userService.getLoggedInUserRoleId();
    this.userRoleService.getUserRoleById(this.loggedInUserRoleId).subscribe(res => {
      this.roles = res;
      this.userRoles = this.roles;
    });
  }


  //select image
  backToUserAdmin() {
    this.showUserAdmin = !this.showUserAdmin;
    this.showNewUser = !this.showNewUser;
  }

  selectImage(image: any) {
    this.selectedImageUrl.setAttribute('src', image.src);
  }

  setImage() {
    this.securityImageUrl.setAttribute('src', this.selectedImageUrl.getAttribute('src'));
    this.closeModal();
  }


  // checkbox
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);


    this.userRoleService.getAllImages().subscribe(res => {
      this.images = res;
    });


    this.securityImageUrl = document.getElementById('security-image');
    this.selectedImageUrl = document.getElementById('selected-image');

    this.selectedImageUrl.setAttribute('src', this.securityImageUrl.getAttribute('src'));
  }

  public closeModal() {
    this.modalRef.hide();
  }

  // form submit
  submitted = false; //form not submited : default
  data: any; //this variable contains our data

  //Show data after form submit and set submitted to true
  onSubmit(data) {
    this.submitted = true;

    // appending the selected bids/bins/submit types to data json, to be send to the server
    if (!_.isUndefined(this.selectedBids) && this.selectedBids.length != 0) {
      data['bid'] = this.selectedBids;
    }
    if (!_.isUndefined(this.selectedBins) && this.selectedBins.length != 0) {
      data['bin'] = this.selectedBins;
    }
    if (!_.isUndefined(this.selectedSubmitTypes) && this.selectedSubmitTypes.length != 0) {
      data['submitType'] = this.selectedSubmitTypes;
    }


    this.selectedRole = this.userRoles.filter(function (node) {
      return node.roleDesc == data.roleDesc;
    });

    data['roleDto'] = Object.assign({}, this.selectedRole[0]);
    delete data['roleDesc'];
    data['ics'] = data.ics ? "1" : "0";
    data['pcs'] = data.pcs ? "1" : "0";
    data['secImg'] = "1";
    data['lastModifiedDate'] = this.date;
    //data['lastLoginDate'] = this.date;
    data['usercreationDate'] = this.date;
    data['password'] = "QWERT$#@!";


    //this.data = JSON.stringify(data);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    //let actionValue = "create";
    this.http.post('http://10.129.155.104:8080/user/createUser', JSON.stringify(data), options).subscribe(
      data => {
        this.showSuccess();
      },
      err => {
        this.showError();
      }
    );

    console.log(data);
  }
  showSuccess() {
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'Success!', detail: 'User updation successfull' });
  }

  showError() {
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Error!', detail: 'User updation failed' });
  }
}
