import { Component, OnInit,ElementRef } from '@angular/core';
import { Util } from '../../util';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  utilObject: Util;
  constructor(private elRef: ElementRef) { 
    this.utilObject = new Util();
  }

  ngOnInit() {
  }
  onkeyup(event) {
    this.utilObject.onFocus(event.target.value, this.elRef.nativeElement, event.keyCode);
  }

}
