import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms';
import { CalendarModule, CarouselModule, DialogModule,CheckboxModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FileUploadModule } from 'primeng/primeng';
import { UserService } from './services/userservices';
import { UserLoginService } from './services/userLoginService';
import { MessageService } from './services/message.service';
import { ClickOutsideModule } from 'ng4-click-outside';
import {
  InputMaskModule,
  PickListModule,
  AccordionModule,
  AutoCompleteModule, DataTableModule, SharedModule, TooltipModule, ConfirmDialogModule, GrowlModule, DropdownModule
} from 'primeng/primeng';
import { ModalModule } from 'ngx-bootstrap/modal';

import { EqualValidator } from './components/password.match.directive';
import { AngularFontAwesomeModule } from 'angular-font-awesome/angular-font-awesome';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { MainComponent } from './shared/main/main.component';
import { FooterComponent } from './shared/footer/footer.component';
import { FaqComponent } from './shared/faq/faq.component';
import { RulesComponent } from './shared/rules/rules.component';
// import { LoginComponent } from './shared/login/login.component';
// import { PcsHomeComponent } from './components/pcs-home/pcs-home.component';

import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { HomePageComponent } from './components/home/home-page.component';
import { ManualEntryComponent } from './components/manual-entry/manual-entry.component';
import { ViewRecordsComponent } from './components/view-records/view-records.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { PreferencesComponent } from './components/preferences/preferences.component';
import { ManualEntryHeaderComponent } from './components/manual-entry/manual-entry-header/manual-entry-header.component';
import { ManualEntrySubmissionTypeComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-submission-type.component';
import { ManualEntryPrepaidEnrollmentComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-enrollment/manual-entry-prepaid-enrollment.component';
import { ManualEntryDeclinedPrepaidEnrollmentComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-declined-prepaid-enrollment/manual-entry-declined-prepaid-enrollment.component';
import { ManualEntryProvisionalCreditRequestComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-provisional-credit-request/manual-entry-provisional-credit-request.component';
import { ManualEntryPrepaidInquiryComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-inquiry/manual-entry-prepaid-inquiry.component';
import { ManualEntryPrepaidFraudComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-fraud/manual-entry-prepaid-fraud.component';
import { ManualEntryDeleteComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-delete/manual-entry-delete.component';

import { LoadReloadComponent } from './components/manual-entry/manual-entry-submission-type/load-reload/load-reload.component';
import { UserAdminComponent } from './components/user-admin/user-admin.component';
import { NewUserComponent } from './components/user-admin-createuser/new-user.component';
import { ReceiveFilesComponent } from './components/receive-files/receive-files.component';
import { ReportsComponent } from './components/reports/reports.component';
import { EditUserComponent } from './components/user-admin-edituser/edit-user.component';

//Log in service part
import { AuthGuard } from '../app/_guard/index';
import { AuthAnonymousGuard } from '../app/_guard/auth.anonymousguard';
import { AuthenticationService, Auth_UserService } from '../app/_services/index';
import { LoginComponent } from './shared/login/login.component';
import { PcsHomeComponent } from './components/pcs-home/pcs-home.component';
import { HttpModule, BaseRequestOptions } from '@angular/http';
// used to create fake backend
import { fakeBackendProvider } from '../app/_helpers/fake-backend';
import { MockBackend, MockConnection } from '@angular/http/testing';

//client-side service 
import { Client } from '../app/http-client.service';
import { CommonErrorComponent } from './shared/common-error/common-error.component';
import { NotFoundComponent } from './shared/not-found/not-found.component'




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    FaqComponent,
    RulesComponent,
    LoginComponent,
    FileUploadComponent,
    PcsHomeComponent,
    HomePageComponent,
    ManualEntryComponent,
    ViewRecordsComponent,
    ManualEntryComponent,
    FileUploadComponent,
    PreferencesComponent,
    ManualEntryHeaderComponent,
    ManualEntrySubmissionTypeComponent,
    ManualEntryPrepaidEnrollmentComponent,
    LoadReloadComponent,
    ManualEntryDeclinedPrepaidEnrollmentComponent,
    ManualEntryProvisionalCreditRequestComponent,
    ManualEntryPrepaidInquiryComponent,
    ManualEntryPrepaidFraudComponent,
    ManualEntryDeleteComponent,
    UserAdminComponent,
    ReportsComponent,
    ReceiveFilesComponent,
    NewUserComponent,
    EditUserComponent,
    EqualValidator,
    CommonErrorComponent,
    NotFoundComponent
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    AccordionModule,
    CalendarModule,
    CarouselModule,
    FileUploadModule,
    InputMaskModule,
    TooltipModule,
    ConfirmDialogModule,
    GrowlModule,
    DropdownModule,
    BrowserModule,
    BrowserAnimationsModule,
    DataTableModule,
    SharedModule,
    AccordionModule,
    DialogModule,
    CheckboxModule,
    AngularFontAwesomeModule,
    ModalModule.forRoot(),
    PickListModule,
    RouterModule.forRoot(routes),
    HttpModule,
    ClickOutsideModule

  ],
  exports: [
    AccordionModule,
    ModalModule,
  ],
  providers: [
    UserLoginService,
    UserService,
    AuthGuard,
    AuthAnonymousGuard,
    AuthenticationService,
    Auth_UserService,
    BaseRequestOptions,
    MessageService,
    Client,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }