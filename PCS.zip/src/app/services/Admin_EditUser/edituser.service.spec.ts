import { TestBed, inject } from '@angular/core/testing';

import { EdituserService } from './edituser.service';

describe('EdituserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EdituserService]
    });
  });

  it('should be created', inject([EdituserService], (service: EdituserService) => {
    expect(service).toBeTruthy();
  }));
});
