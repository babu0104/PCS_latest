import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class userRoleService {
    constructor(private http: Http) { }

    getUserRoleById(roleId): Observable<any[]> {
        // let urlParams = new URLSearchParams();
        // urlParams.set('action', 'update');
        let actionValue = "update";
        let data = { 'roleId': roleId };
        return this.http.post('http://10.129.155.104:8080/user/rolesbyId?action=' + actionValue, data)
            .map(res => res.json())
    }

    getuserrbid(): Observable<any[]> {
        let data = { 'userId': 'meghana17' };
        return this.http.post('http://10.129.155.104:8080/user/bid/uderId', data)
            .map(res => res.json())
    }

    getuserrbin(): Observable<any[]> {
        return this.http.get('http://10.129.155.104:8080/user/bin')
            .map(res => res.json())
    }

    getsubmissiontypes(): Observable<any[]> {
        return this.http.get('http://10.129.155.104:8080/user/submissiontypes')
            .map(res => res.json())
    }

    getAllImages(): Observable<any[]> {
        return this.http.get('http://10.129.155.104:8080/getAllImages')
            .map(res => res.json())
    }

}

