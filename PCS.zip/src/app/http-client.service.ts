import { environment } from '../environments/environment';
import { Injectable } from '@angular/core';
import { Headers, Response, RequestOptions, URLSearchParams, Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
/**
 * Common class for rest service
*/
@Injectable()
export class Client {

    private endPointURL: string;
    private JSON = 'application/json';
    private TEXT = 'application/text';
    private http : any;
    constructor(private router: Router, _http: Http) {
        this.endPointURL = environment.apiUrl;
        this.http = _http;
    }
    /**
     * Getting JSON/TEXT
    */
    public get(service: String, action: String, data?: any, appendHeader: boolean = true): Observable<ResponseModel> {
        if (appendHeader) {
            if (!data) {
                return this.http.get(`${this.endPointURL}/${service}/${action}`, this.getRequestOptions(this.JSON))
                    .map(this.handleSuccess)
                    .catch(this.handleError);
            } else {
                return this.http.get(`${this.endPointURL}/${service}/${action}/${data}`, this.getRequestOptions(this.JSON))
                    .map(this.handleSuccess)
                    .catch(this.handleError);
            }
        } else {
            if (!data) {
                return this.http.get(`${this.endPointURL}/${service}/${action}`)
                    .map(this.handleSuccess)
                    .catch(this.handleError);
            } else {
                return this.http.get(`${this.endPointURL}/${service}/${action}/${data}`)
                    .map(this.handleSuccess)
                    .catch(this.handleError);
            }
        }
    }  

    /**
     * Posting JSON
    */
    public postJSON(service: String, action: String, data: any, id?: string): Observable<ResponseModel> {
        const options: RequestOptions = this.getRequestOptions(this.JSON);
        if (!!id) {
            return this.http.post(`${this.endPointURL}/${service}/${action}/${id}`, JSON.stringify(data), options)
                .map(this.handleSuccess)
                .catch(this.handleError);
        } else {
            return this.http.post(`${this.endPointURL}/${service}/${action}`, JSON.stringify(data), options)
                .map(this.handleSuccess)
                .catch(this.handleError);
        }
    }
        /**
     * Gets request options
    */
    public getRequestOptions(contentType: string) {
        const headers = new Headers({ 'Content-Type': contentType });
        const authToken = sessionStorage.getItem('authToken');
        if (!!authToken) {
            headers.append('X-XSRF-Token', authToken);
        }
        const options = new RequestOptions({ headers: headers, withCredentials: true });
        return options;
    }


    /**
     * Hanldes success from service
     */
    private handleSuccess(success: Response) {
        const model = new ResponseModel();
        model.message = success.text();
        try {
            model.json = success.json();
        } catch (error) {
            // No JSON
        }
        model.isSuccess = true;
        return model;
    }

    /**
    * Hanldes error from service
    */
    private handleError(error: any) {
        let errMsg: string;
        const model = new ResponseModel();
        if (error instanceof Response) {
            const body = error.json() || '';
            model.json = error.json();
            if (body.exception && body.exception.indexOf('FinExpException') > 0) {
                errMsg = `${body.message}`;
            } else {
                errMsg = 'An error occurred while processing your request. Please try again later.';
            }
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        model.message = errMsg;
        model.isSuccess = false;
        return Observable.throw(model);
    }

}

/**
 * Wrapped object of Response from the server
 *
 */
@Injectable()
export class ResponseModel {
    message: string;
    isSuccess: boolean;
    json: any;
    constructor() {
    }
}
